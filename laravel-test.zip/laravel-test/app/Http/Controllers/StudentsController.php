<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StudentsController extends Controller
{
    public function index()
    {
        return view('student.index');
    }

    public function create()
    {
        return view('student.create');
    }

    public function store(Request $request)
    {
       $this->validate($request, [
           'name' => 'required|min:3',
           'email' => 'required|email'
       ]);



    }
}
