<?php $__env->startSection('title', 'Student Create'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <form action="<?php echo e(url('/student/create')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control">
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control">
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                </div>

                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="address" class="form-control">
                </div>

                <div class="form-group">
                  <button type="submit" class="btn btn-info">Save</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>