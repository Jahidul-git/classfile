@extends('layout.master')
@section('title', 'Student List')

@section('content')
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <table class="table table-striped table-hover">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                </tr>

                <tr>
                    <td>Liton</td>
                    <td>mail@yahoo.com</td>
                    <td>Dhaka</td>
                </tr>
            </table>
        </div>
    </div>
@endsection