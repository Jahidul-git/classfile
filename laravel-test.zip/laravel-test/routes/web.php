<?php



Route::group(['prefix' => 'student'], function (){

    Route::get('/', 'StudentsController@index');
    Route::get('/create', 'StudentsController@create');
    Route::post('/create', 'StudentsController@store');

});